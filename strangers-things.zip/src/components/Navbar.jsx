import { Link } from "react-router-dom";

export default function Navbar() {
    return (
      <div id="navbar">
        <div id="navbar-header">
            Stranger's Things
        </div>
        <Link to={"/"}>HOME</Link>
        <Link to={"/posts"}>POSTS</Link>
        <Link to={"/account/login"}>LOGIN</Link>
      </div>
    );
  }