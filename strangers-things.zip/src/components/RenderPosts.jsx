import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router-dom'
import { fetchPosts } from '../api/ajaxHelper';


export default function RenderPosts() {
  const [posts, setPosts] = useState([]);
  const navigate = useNavigate();

  function renderPosts() {
    console.log("posts: ", posts);
    return posts.map((post) => {
      return (
        <div key={post._id} className="post" >
          <h2>{post.title}</h2>
          <h4>{post.description}</h4>
          <h4>{post.price}</h4>
          <h4>{post.location}</h4>
          <p>{post.author.username}</p>
          <button onClick={() => navigate(`/posts/${post._id}`)}>VIEW</button>
        </div>
      )
    })
  }
  
  useEffect(() => {
    async function getPostsHandler() {
      const result = await fetchPosts();
      console.log("results: ", result);
      setPosts(result);
    }
    getPostsHandler();

  }, [])

  return (
    <div>
      <div>
        <h2>Posts</h2>
        <p onClick={() => navigate(`/posts/addNewPost`)}>ADD POST</p>
      </div>
      <div>
        {renderPosts()}
      </div>
    </div>
  )
}